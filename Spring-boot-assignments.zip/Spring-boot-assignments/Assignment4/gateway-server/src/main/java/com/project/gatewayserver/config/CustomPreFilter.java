package com.project.gatewayserver.config;

import com.project.gatewayserver.exception.BadUserCredentialsException;
import com.project.gatewayserver.response.ErrorResponse;
import com.project.gatewayserver.util.RouterValidator;
import com.project.gatewayserver.util.TokenHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;


import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;


@Component
@RefreshScope
public class CustomPreFilter implements GatewayFilter {

    @Autowired
    private RouterValidator routerValidator;
    @Autowired
    private TokenHelper tokenHelper;

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        ServerHttpRequest request = exchange.getRequest();
        if (routerValidator.isSecured.test(request)){
            if (this.isAuthMissing(request)){
                return this.onError(exchange, "Authorization header is missing in request",
                       HttpStatus.UNAUTHORIZED);
                //throw new BadCredentialsException("Authorization header is missing in request ");
            }
            final String authHeader = this.getAuthHeader(request);
            final String token = authHeader.split(" ")[1];
            if(authHeader.split(" ")[0].equalsIgnoreCase("Basic")) {
                return this.onError(exchange, "Bearer token is missing in Authorization header",
                        HttpStatus.UNAUTHORIZED);
            }
            try {
                tokenHelper.tokenValid(token);
            } catch (BadUserCredentialsException ex) {
                return this.onError(exchange, "Token Expired",
                        HttpStatus.UNAUTHORIZED);
            }

        }
        return chain.filter(exchange);
    }

    private String getAuthHeader(ServerHttpRequest request) {
        return request.getHeaders().getOrEmpty("Authorization").get(0);
    }


    private Mono<Void> onError(ServerWebExchange exchange, String err, HttpStatus httpStatus) {
        ErrorResponse errResponse = new ErrorResponse(HttpStatus.UNAUTHORIZED.value(), System.currentTimeMillis(),err);
        ServerHttpResponse response = exchange.getResponse();
        response.setStatusCode(httpStatus);
       // return response.writeAndFlushWith(Mono.error(new BadUserCredentialsException(err)));
        return response.setComplete();
    }

    private boolean isAuthMissing(ServerHttpRequest request) {
        return !request.getHeaders().containsKey("Authorization");
    }

}
