package com.project.springsecurity.controller;

import com.project.springsecurity.entity.User;
import com.project.springsecurity.response.SuccessResponse;
import com.project.springsecurity.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    UserService userService;

    SuccessResponse response = null;

    @PostMapping
    @ResponseStatus(code = HttpStatus.CREATED)
    public ResponseEntity<SuccessResponse> createUserProfile(@RequestBody User profile) {
        response = new SuccessResponse(HttpStatus.OK.value(), "Success", System.currentTimeMillis(),
                userService.createUser(profile) );
        return new ResponseEntity<>(response,HttpStatus.OK );
    }

    @GetMapping("/{userId}")
    public ResponseEntity<SuccessResponse> getUserProfile(@PathVariable String userId) {
        response = new SuccessResponse(HttpStatus.OK.value(), "Success", System.currentTimeMillis(),
                userService.getUser(userId));
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping()
    public ResponseEntity<SuccessResponse> getUserProfile() {
        response = new SuccessResponse(HttpStatus.OK.value(), "Success", System.currentTimeMillis(),
                userService.getAllUsers());
        return new ResponseEntity<>(response, HttpStatus.OK);

    }

    @PutMapping()
    public ResponseEntity<SuccessResponse> updateUserProfile( @RequestBody User profile) {
        response = new SuccessResponse(HttpStatus.OK.value(), "Success", System.currentTimeMillis(),
                userService.updateUser(profile));
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @DeleteMapping("/{userId}")
    @ResponseStatus(code = HttpStatus.OK)
    public ResponseEntity<SuccessResponse> deleteUser(@PathVariable String userId) {
        response = new SuccessResponse(HttpStatus.OK.value(), "Success", System.currentTimeMillis(),
                userService.deleteUser(userId) == true ? "User Deleted successfully" : "Server error");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

}
