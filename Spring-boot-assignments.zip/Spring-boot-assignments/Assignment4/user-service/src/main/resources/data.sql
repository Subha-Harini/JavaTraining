INSERT INTO USER (user_id, first_name, last_name, email, password) VALUES
  ('user1','Harini', 'k', 'harini@gmail.com','password'),
   ('user2','Har', 'k', 'har@gmail.com','password'),
  ('user3','Hari', 'k', 'hari@gmail.com','password'),
  ('user4','Hariii', 'k', 'hariii@gmail.com','password'),
  ('user5','Hariiiii', 'k', 'hariiiii@gmail.com','password');