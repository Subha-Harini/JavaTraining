package com.project.userservice.security;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;

import com.project.userservice.entity.User;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
public class TokenHelper {

	@Value("${jwt.secret}")
	private String SECRET;
	
	@Value("${jwt.expires-in}")
	private String EXPIRES_IN;
	
	@Value("${jwt.header}")
	private String AUTH_HEADER;
	
	@Value("${jwt.issuer}")
	private String ISSUER;


	public String generateToken(User user) {
		return JWT.create()
				.withSubject(user.getUserId())
				.withIssuedAt(new Date(System.currentTimeMillis()))
				.withIssuer(ISSUER)
				.withExpiresAt(new Date(System.currentTimeMillis() + 1000 * Integer.parseInt(EXPIRES_IN)))
				.sign(this.getAlgorithm());
	}

	private Algorithm getAlgorithm() {
		return Algorithm.HMAC512(SECRET);
	}

}
