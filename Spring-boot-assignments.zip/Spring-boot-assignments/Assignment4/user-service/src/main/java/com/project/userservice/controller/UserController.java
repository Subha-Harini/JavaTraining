package com.project.userservice.controller;


import com.project.userservice.entity.User;
import com.project.userservice.response.SuccessResponse;
import com.project.userservice.service.AuthService;
import com.project.userservice.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService service;

    @Autowired
    private AuthService authService;

    SuccessResponse response = null;

    @PostMapping
    @ResponseStatus(code = HttpStatus.CREATED)
    public ResponseEntity<SuccessResponse> createUserProfile(@RequestBody User profile) {
        response = new SuccessResponse(HttpStatus.OK.value(), "Success", System.currentTimeMillis(),
                service.createUser(profile));
        return new ResponseEntity<>(response,HttpStatus.OK );
    }

    @GetMapping("/{userId}")
    public ResponseEntity<SuccessResponse> getUserProfile(@PathVariable String userId) {
        response = new SuccessResponse(HttpStatus.OK.value(), "Success", System.currentTimeMillis(),
                service.getUser(userId));
        return new ResponseEntity<>(response,HttpStatus.OK );
    }

    @GetMapping()
    public ResponseEntity<SuccessResponse> getUserProfile() {
        response = new SuccessResponse(HttpStatus.OK.value(), "Success", System.currentTimeMillis(),
                service.getAllUsers());
        return new ResponseEntity<>(response,HttpStatus.OK );
    }

    @PutMapping()
    public ResponseEntity<SuccessResponse> updateUserProfile( @RequestBody User profile) {
        response = new SuccessResponse(HttpStatus.OK.value(), "Success", System.currentTimeMillis(),
                service.updateUser(profile));
        return new ResponseEntity<>(response,HttpStatus.OK );
    }

    @DeleteMapping("/{userId}")
    @ResponseStatus(code = HttpStatus.OK)
    public ResponseEntity<SuccessResponse> deleteEmployee(@PathVariable String userId) {
        response = new SuccessResponse(HttpStatus.OK.value(), "Success", System.currentTimeMillis(),
                service.deleteUser(userId) == true ? "User Deleted successfully" : "Server error");
        return new ResponseEntity<>(response,HttpStatus.OK );
    }

    @PostMapping("/authenticate")
    public ResponseEntity<SuccessResponse> authenticate(@RequestHeader("Authorization") String authHeader){
        response = new SuccessResponse(HttpStatus.OK.value(), "Success", System.currentTimeMillis(),
                this.authService.authenticate(authHeader));
        return new ResponseEntity<>(response,HttpStatus.OK );
    }
}
