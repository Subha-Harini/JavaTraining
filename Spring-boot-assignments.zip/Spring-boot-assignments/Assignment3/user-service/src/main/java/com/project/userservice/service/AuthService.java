package com.project.userservice.service;


import com.project.userservice.security.AppUserDetailsService;
import com.project.userservice.security.TokenHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import java.util.Base64;

@Service
public class AuthService {

    @Autowired
    private AuthenticationManager authManager;

    @Autowired
    private TokenHelper tokenHelper;

    @Autowired
    private AppUserDetailsService service;

    public String authenticate(String header) {
        System.out.println(header);
        String userId = getUser(header);
        final UserDetails userDetails = service.loadUserByUsername(userId);
        final String jwt = tokenHelper.generateToken(userDetails);
        return jwt;
    }


    private String getUser(String authHeader) {
        String encodedCredentials = authHeader.split(" ")[1];
        String decodedCredentials = new String (Base64.getDecoder().decode(encodedCredentials));
        return decodedCredentials.split(":")[0];
    }
}
