package com.project.productservice.service;

import com.project.productservice.entity.Product;
import com.project.productservice.exception.ResourceAlreadyExistsException;
import com.project.productservice.exception.ResourceNotFoundException;
import com.project.productservice.repo.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;
    private static final String PRODUCT_ALREADY_EXISTS_MSG = "product with product id %s already exists";
    private static final String PRODUCT_DOESNT_EXISTS_MSG = "product with product Id %s doesn't exist";

    public Product createProduct(Product product) throws ResourceAlreadyExistsException {
        if(productRepository.existsById(product.getProductId())){
            throw new ResourceAlreadyExistsException(String.format(PRODUCT_ALREADY_EXISTS_MSG, product.getProductId()));
        }
        return productRepository.save(product);
    }

    public Product getProduct(int productId) {
        return productRepository.findById(productId)
                .orElseThrow(() -> new ResourceNotFoundException(String.format(PRODUCT_DOESNT_EXISTS_MSG,productId)));
    }

    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    public Product updateProduct(Product profile) {
        this.getProduct(profile.getProductId());
        return productRepository.save(profile);
    }

    public boolean deleteProduct(int productId) {
        this.getProduct(productId);
        productRepository.deleteById(productId);
        return true;
    }
}
