package com.project.userservice.controller;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name="product-service")
public interface ProductRestConsumer {

    @GetMapping("/product")
    public ResponseEntity<?> getAllProducts();

    @GetMapping("/product/{id}")
    public  ResponseEntity<?> getProductById(@PathVariable Integer id);
}
