package com.project.userservice.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(name="orders")
@Getter
@Setter
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(nullable = false, length = 5)
    private int orderId;

    @ManyToOne
    @JoinColumn(name="userId", nullable=false)
    private User user;

    @Column(name = "product_id")
    private int productId;

    @Column(name = "quantity")
    private int quantity;

}
