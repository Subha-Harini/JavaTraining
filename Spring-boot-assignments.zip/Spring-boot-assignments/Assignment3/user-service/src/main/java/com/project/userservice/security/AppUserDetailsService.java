package com.project.userservice.security;


import com.project.userservice.repo.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;


@Service
public class AppUserDetailsService implements UserDetailsService {

    @Autowired
    UserRepository repository;


    public AppUserDetailsService(UserRepository repo) {
        super();
        this.repository = repo;
    }

    @Override
    public UserDetails loadUserByUsername(String userId) {
        com.project.userservice.entity.User user = repository.findById(userId)
                    .orElseThrow(() -> new UsernameNotFoundException(String.format("Authentication failed", userId)));
        UserDetails userDetail = org.springframework.security.core.userdetails.User
                .withUsername(userId).password(user.getPassword()).roles("User").build();
        return userDetail;
    }
}
