package com.project.gatewayserver.util;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.TokenExpiredException;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.project.gatewayserver.exception.BadUserCredentialsException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import javax.servlet.http.HttpServletRequest;
import java.util.Date;

@Component
public class TokenHelper {

	@Value("${jwt.secret}")
	private String SECRET;
	
	@Value("${jwt.header}")
	private String AUTH_HEADER;

	
	private static final String BEARER = "Bearer ";
	
	private JWTVerifier verifier;

	
	public String getToken(HttpServletRequest req) {
		String authHeader = req.getHeader(AUTH_HEADER);
		if(authHeader != null && authHeader.startsWith(BEARER)) {
			return authHeader.substring(BEARER.length());
		}
		return null;
	}
	
	public String getUsername(String token) {
		return JWT.decode(token).getSubject();
	}
	
	public boolean tokenValid(String token) {
		try {
			DecodedJWT jwt = this.getVerifier().verify(token);
			System.out.println(jwt);
			return !tokenExpired(jwt);
		} catch(TokenExpiredException te) {
			throw new BadUserCredentialsException("Token Expired");
		}
	}
	
	private boolean tokenExpired(DecodedJWT jwt) {
		return jwt.getExpiresAt().before(new Date(System.currentTimeMillis()));
	}
	
	private JWTVerifier getVerifier() {
		if(this.verifier == null) {
			this.verifier = JWT.require(getAlgorithm()).build();
		}
		return this.verifier;
	}
	
	private Algorithm getAlgorithm() {
		return Algorithm.HMAC512(SECRET);
	}

}
