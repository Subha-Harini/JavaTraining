package com.project.springsecurity.response;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class SuccessResponse {
    private int status;
    private String message;
    private long timeStamp;
    private Object data;
}
