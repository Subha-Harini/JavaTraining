package com.project.springsecurity.enums;

public enum Role {

	ADMIN, NORMAL
}
