package com.project.userservice.controller;

import com.project.userservice.request.OrderRequest;
import com.project.userservice.response.SuccessResponse;
import com.project.userservice.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/user/order")
public class OrderController {

    @Autowired
    private OrderService orderService;

    SuccessResponse response = null;

    @PostMapping
    public ResponseEntity postOrder(@RequestBody OrderRequest order){
        response = new SuccessResponse(HttpStatus.OK.value(), "Success", System.currentTimeMillis(),
                orderService.postOrder(order));
        return new ResponseEntity<>(response,HttpStatus.OK );
    }

    @GetMapping("/{userId}")
    public ResponseEntity<SuccessResponse> getOrderByUserId(@PathVariable String userId){
        response = new SuccessResponse(HttpStatus.OK.value(), "Success", System.currentTimeMillis(),
                orderService.getOrdersByUserId(userId));
        return new ResponseEntity<>(response,HttpStatus.OK );
    }

    @GetMapping("details/{orderId}")
    public ResponseEntity getOrderByUserId(@PathVariable int orderId){
        response = new SuccessResponse(HttpStatus.OK.value(), "Success", System.currentTimeMillis(),
                orderService.getOrdersByOrderId(orderId));
        return new ResponseEntity<>(response,HttpStatus.OK );
    }

    @PutMapping
    public ResponseEntity updateOrder(@RequestBody OrderRequest order){
        response = new SuccessResponse(HttpStatus.OK.value(), "Success", System.currentTimeMillis(),
                orderService.updateOrder(order));
        return new ResponseEntity<>(response,HttpStatus.OK );
    }

    @DeleteMapping("/{orderId}")
    public ResponseEntity deleteEmployee(@PathVariable int orderId) {
        response = new SuccessResponse(HttpStatus.OK.value(), "Success", System.currentTimeMillis(),
                orderService.deleteOrder(orderId));
        return new ResponseEntity<>(response,HttpStatus.OK );
    }

}
