package com.project.userservice.service;

import com.project.userservice.entity.User;
import com.project.userservice.exception.ResourceAlreadyExistsException;
import com.project.userservice.exception.ResourceNotFoundException;
import com.project.userservice.repo.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;
    private static final String USER_ALREADY_EXISTS_MSG = "user with user id %s already exists";
    private static final String USER_DOESNT_EXISTS_MSG = "user with user Id %s doesn't exist";

    public User createUser(User profile) throws ResourceAlreadyExistsException {
        if(userRepository.existsById(profile.getUserId())){
            throw new ResourceAlreadyExistsException(String.format(USER_ALREADY_EXISTS_MSG, profile.getUserId()));
        }
        return userRepository.save(profile);
    }


    public User getUser(String userId) {
        return userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException(String.format(USER_DOESNT_EXISTS_MSG,userId)));
    }

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }


    public User updateUser(User profile) {
        this.getUser(profile.getUserId());
        return userRepository.save(profile);
    }

    public boolean deleteEmployee(String userId) {
        this.getUser(userId);
        userRepository.deleteById(userId);
        return true;
    }
}
