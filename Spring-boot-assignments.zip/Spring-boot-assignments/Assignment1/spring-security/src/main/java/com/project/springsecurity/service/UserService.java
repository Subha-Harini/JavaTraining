package com.project.springsecurity.service;

import com.project.springsecurity.entity.User;
import com.project.springsecurity.exception.ResourceAlreadyExistsException;
import com.project.springsecurity.exception.ResourceNotFoundException;
import com.project.springsecurity.repo.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepo;

    private static final String USER_ALREADY_EXISTS_MSG = "User with user id %s already exists";
    private static final String USER_DOESNT_EXISTS_MSG = "User with user Id %s doesn't exist";

    public User createUser(User profile) throws ResourceAlreadyExistsException {
        if(userRepo.existsById(profile.getUserId())){
            throw new ResourceAlreadyExistsException(String.format(USER_ALREADY_EXISTS_MSG, profile.getUserId()));
        }
        return userRepo.save(profile);
    }


    public User getUser(String userId) {
        return userRepo.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException(String.format(USER_DOESNT_EXISTS_MSG,userId)));
    }

    public List<User> getAllUsers() {
        return userRepo.findAll();
    }


    public User updateUser(User profile) {
        this.getUser(profile.getUserId());
        return userRepo.save(profile);
    }

    public boolean deleteUser(String userId) {
        this.getUser(userId);
         userRepo.deleteById(userId);
         return true;
    }


}
