package com.project.userservice.exception;

public class BadUserCredentialsException extends RuntimeException{

    private static final long serialVersionUID = 1L;

    public BadUserCredentialsException(String message) {
        super(message);
    }
}
