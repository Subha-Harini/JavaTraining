package com.project.springsecurity.security;


import com.project.springsecurity.repo.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;


@Service
public class AppUserDetailsService implements UserDetailsService {

    @Autowired
    EmployeeRepository repository;


    public AppUserDetailsService(EmployeeRepository repo) {
        super();
        this.repository = repo;
    }

    @Override
    public UserDetails loadUserByUsername(String userId) {
        com.project.springsecurity.entity.Employee employee = repository.findById(userId)
                    .orElseThrow(() -> new UsernameNotFoundException(String.format("Authentication failed", userId)));
        UserDetails userDetail = org.springframework.security.core.userdetails.User
                .withUsername(userId).password(employee.getPassword()).roles("Employee").build();
        return userDetail;
    }
}
