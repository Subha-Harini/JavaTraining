package com.project.springsecurity.security;


import com.project.springsecurity.repo.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;


@Service
public class AppUserDetailsService implements UserDetailsService {

    @Autowired
    UserRepository userRepository;


    public AppUserDetailsService(UserRepository userRepository) {
        super();
        this.userRepository = userRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String userId) {
        com.project.springsecurity.entity.User user = userRepository.findById(userId)
                    .orElseThrow(() -> new UsernameNotFoundException(String.format("Authentication failed", userId)));
        UserDetails userDetail = org.springframework.security.core.userdetails.User
                .withUsername(userId).password(user.getPassword()).roles(user.getRole().toString()).build();
        return userDetail;
    }
}
