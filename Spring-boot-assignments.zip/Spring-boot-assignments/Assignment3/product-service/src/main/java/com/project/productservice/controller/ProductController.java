package com.project.productservice.controller;

import com.project.productservice.entity.Product;
import com.project.productservice.response.SuccessResponse;
import com.project.productservice.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/product")
public class ProductController {

    @Autowired
    private ProductService service;

    SuccessResponse response = null;

    @PostMapping
    @ResponseStatus(code = HttpStatus.CREATED)
    public ResponseEntity<SuccessResponse> createEmployeeProfile(@RequestBody Product product) {
        response = new SuccessResponse(HttpStatus.OK.value(), "Success", System.currentTimeMillis(),
                service.createProduct(product) );
        return new ResponseEntity<>(response,HttpStatus.OK );
    }

    @GetMapping("/{productId}")
    public ResponseEntity<SuccessResponse> getEmployeeProfile(@PathVariable int productId) {
        response = new SuccessResponse(HttpStatus.OK.value(), "Success", System.currentTimeMillis(),
                service.getProduct(productId));
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping()
    public ResponseEntity<SuccessResponse> getEmployeeProfile() {
        response = new SuccessResponse(HttpStatus.OK.value(), "Success", System.currentTimeMillis(),
                service.getAllProducts());
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PutMapping()
    public ResponseEntity<SuccessResponse> updateEmployeeProfile( @RequestBody Product product) {
        response = new SuccessResponse(HttpStatus.OK.value(), "Success", System.currentTimeMillis(),
                service.updateProduct(product));
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @DeleteMapping("/{productId}")
    @ResponseStatus(code = HttpStatus.OK)
    public ResponseEntity<SuccessResponse> deleteEmployee(@PathVariable int productId) {
        response = new SuccessResponse(HttpStatus.OK.value(), "Success", System.currentTimeMillis(),
                service.deleteProduct(productId) == true ? "Product Deleted successfully" : "Server error");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
