package com.project.userservice.service;


import com.project.userservice.entity.User;
import com.project.userservice.exception.BadUserCredentialsException;
import com.project.userservice.security.TokenHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Base64;

@Service
public class AuthService {

    @Autowired
    private TokenHelper tokenHelper;

    @Autowired
    private UserService service;

    public String authenticate(String header) {
        System.out.println(header);
        String userId = getUser(header);
        String password = getPassword(header);
        String jwt = null;
        final User userDetails = service.getUser(userId);
        if(userDetails.getPassword().equalsIgnoreCase(password)) {
            jwt = tokenHelper.generateToken(userDetails);
        }
        else{
            throw new BadUserCredentialsException("Invalid username/password");
        }
        return jwt;
    }


    private String getUser(String authHeader) {
        String encodedCredentials = authHeader.split(" ")[1];
        String decodedCredentials = new String (Base64.getDecoder().decode(encodedCredentials));
        System.out.println(decodedCredentials);
        return decodedCredentials.split(":")[0];
    }

    private String getPassword(String authHeader) {
        String encodedCredentials = authHeader.split(" ")[1];
        String decodedCredentials = new String (Base64.getDecoder().decode(encodedCredentials));
        System.out.println(decodedCredentials);
        return decodedCredentials.split(":")[1];
    }
}
