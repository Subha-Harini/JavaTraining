package com.project.userservice.config;

import com.project.userservice.exception.ResourceNotFoundException;
import feign.codec.ErrorDecoder;
import org.apache.commons.io.IOUtils;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class FeignPropagateBadRequestsConfiguration {

    @Bean
    public ErrorDecoder errorDecoder() {
        return (methodKey, response) -> {
            int status = response.status();
            if (status == 400) {
                String body = "Bad request";
                try {
                    body = IOUtils.toString(response.body().asReader());
                } catch (Exception ignored) {}
                 return new ResourceNotFoundException(body.split(",")[2].split("\"")[3]);
            }else if(status == 503){
                return new RuntimeException(status +" : Service temporarily unavailable");
            }
            else {
                return new RuntimeException(status + " : Internal server error");
            }
        };
    }
}
