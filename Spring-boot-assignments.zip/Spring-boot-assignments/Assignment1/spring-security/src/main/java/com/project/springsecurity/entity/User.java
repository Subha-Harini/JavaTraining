package com.project.springsecurity.entity;


import com.project.springsecurity.enums.Role;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(name="user")
@Getter
@Setter
public class User {


    @Id
    @Column(nullable = false, length = 5)
    private String userId;

    @Column(nullable = false, length = 50)
    private String userName;

    @Column(nullable = false, length = 50)
    private String firstName;

    @Column(nullable = false, length = 50)
    private String lastName;

    @Column(nullable = false, length = 20)
    private String password;

    @Column(nullable = false, length = 10)
    private Role role;



}
