package com.project.userservice.service;


import com.project.userservice.entity.Order;
import com.project.userservice.exception.ResourceNotFoundException;
import com.project.userservice.repo.OrderRepository;
import com.project.userservice.repo.UserRepository;
import com.project.userservice.request.OrderRequest;
import com.project.userservice.response.OrderResponse;
import com.project.userservice.util.OrderUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;


@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private UserRepository userRepository;

    private static final String ORDER_DOESNT_EXISTS_MSG = "order with order Id %s doesn't exist";
    private static final String USER_DOESNT_EXISTS_MSG = "user with user Id %s doesn't exist";

    @Autowired
    private OrderUtil util;

    public OrderResponse postOrder(OrderRequest orderRequest){
        userRepository.findById(orderRequest.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException(String.format(USER_DOESNT_EXISTS_MSG,orderRequest.getUserId())));
        Order o = orderRepository.save(util.orderRequestToOrder(orderRequest));
        return util.orderToOrderResponse(o);
    }

    public List<OrderResponse> getOrdersByUserId(String userId){
        userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException(String.format(USER_DOESNT_EXISTS_MSG,userId)));
        List<Order> orderList = orderRepository.findByUserId(userId);
        List<OrderResponse> orderResponseList = new ArrayList<>();
        for(int i=0; i< orderList.size(); i++){
            orderResponseList.add(util.orderToOrderResponse(orderList.get(i)));
        }
        return orderResponseList;
    }

    public OrderResponse getOrdersByOrderId(int orderId) {
        Order o =  orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException(String.format(ORDER_DOESNT_EXISTS_MSG,orderId)));

        return util.orderToOrderResponse(o);
    }

    public OrderResponse updateOrder(OrderRequest orderRequest){
        Order o =  orderRepository.findById(orderRequest.getOrderId())
                .orElseThrow(() -> new ResourceNotFoundException(String.format(ORDER_DOESNT_EXISTS_MSG,orderRequest.getOrderId())));
        Order finalOrder =  util.updateOrder(orderRequest,o);
        orderRepository.save(finalOrder);
        return util.orderToOrderResponse(finalOrder);
    }

    public String deleteOrder(int orderId){
        Order o =  orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException(String.format(ORDER_DOESNT_EXISTS_MSG,orderId)));
        orderRepository.deleteById(orderId);
        return "Order deleted successfully";
    }
}
