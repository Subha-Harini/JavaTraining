package com.project.userservice.exception;

import com.project.userservice.response.ErrorResponse;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;



@RestControllerAdvice
public class GlobalExceptionHandler {
    private static final String NOT_FOUND = "NOT_FOUND";
    private static final String CONFLICT = "CONFLICT";
    private static final String BAD_REQUEST = "BAD_REQUEST";
    private static final String UNAUTHORIZED = "UNAUTHORIZED";
    private static final String BAD_CREDENTIALS = "BAD_CREDENTIALS";
    private static final String INTERNAL_SERVER_ERROR = "INTERNAL_SERVER_ERROR";

    ErrorResponse response = null;

    @ResponseStatus(code = HttpStatus.CONFLICT)
    @ExceptionHandler(ResourceAlreadyExistsException.class)
    public ErrorResponse resourceAlreadyExists(ResourceAlreadyExistsException ex) {
        response = new ErrorResponse(HttpStatus.CONFLICT.value(),  System.currentTimeMillis(), ex.getMessage());
        return response;
    }

    @ResponseStatus(code = HttpStatus.BAD_REQUEST)
    @ExceptionHandler(ResourceNotFoundException.class)
    public ErrorResponse resourceNotFound(ResourceNotFoundException ex) {
        response = new ErrorResponse(HttpStatus.NOT_FOUND.value(), System.currentTimeMillis(), ex.getMessage());
        return response;
    }

    @ResponseStatus(code = HttpStatus.UNAUTHORIZED)
    @ExceptionHandler(BadUserCredentialsException.class)
    public ErrorResponse unauthorizedException(BadUserCredentialsException ex) {
        response = new ErrorResponse(HttpStatus.UNAUTHORIZED.value(), System.currentTimeMillis(), ex.getMessage());
        return response;
    }

    @ResponseStatus(code = HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(RuntimeException.class)
    public ErrorResponse RuntimeExceptionException(RuntimeException ex) {
        response = new ErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), System.currentTimeMillis(), ex.getMessage());
        return response;
    }

}
