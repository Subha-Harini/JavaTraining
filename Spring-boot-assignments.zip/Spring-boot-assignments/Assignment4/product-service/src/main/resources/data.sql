INSERT INTO CATEGORY (category_id, category) VALUES
  (1, 'Mobile'),
   (2, 'Laptop'),
  (3, 'Headphones');
  
 INSERT INTO product (product_id, product_name, product_quantity, category_id) VALUES
  (1,'Boat  headphones', 2, 3),
   (2,'JBL headphones', 4, 3),
  (3,'Plantronics headphones', 3, 3),
  (4,'Nokia Mobile', 4, 1),
  (5,'Samsung Mobile', 4, 1),
  (6,'MI Mobile', 4, 1),
  (7,'DELL Laptop', 4, 2),
  (8,'HP Laptop', 4, 2),
  (9,'LG Laptop', 4, 2);
  
  
