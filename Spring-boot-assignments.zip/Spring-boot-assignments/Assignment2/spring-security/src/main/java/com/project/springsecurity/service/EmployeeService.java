package com.project.springsecurity.service;

import com.project.springsecurity.entity.Employee;
import com.project.springsecurity.exception.ResourceAlreadyExistsException;
import com.project.springsecurity.exception.ResourceNotFoundException;
import com.project.springsecurity.repo.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;
    private static final String EMPLOYEE_ALREADY_EXISTS_MSG = "employee with employee id %s already exists";
    private static final String EMPLOYEE_DOESNT_EXISTS_MSG = "employee with employee Id %s doesn't exist";

    public Employee createEmployee(Employee profile) throws ResourceAlreadyExistsException {
        if(employeeRepository.existsById(profile.getEmployeeId())){
            throw new ResourceAlreadyExistsException(String.format(EMPLOYEE_ALREADY_EXISTS_MSG, profile.getEmployeeId()));
        }
        return employeeRepository.save(profile);
    }


    public Employee getEmployee(String employeeId) {
        return employeeRepository.findById(employeeId)
                .orElseThrow(() -> new ResourceNotFoundException(String.format(EMPLOYEE_DOESNT_EXISTS_MSG,employeeId)));
    }

    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }


    public Employee updateEmployee(Employee profile) {
        this.getEmployee(profile.getEmployeeId());
        return employeeRepository.save(profile);
    }

    public boolean deleteEmployee(String userId) {
        this.getEmployee(userId);
        employeeRepository.deleteById(userId);
        return true;
    }
}
