package com.project.userservice.util;

import com.project.userservice.controller.ProductRestConsumer;
import com.project.userservice.entity.Order;
import com.project.userservice.exception.ResourceNotFoundException;
import com.project.userservice.repo.UserRepository;
import com.project.userservice.request.OrderRequest;
import com.project.userservice.response.CategoryResponse;
import com.project.userservice.response.OrderResponse;
import com.project.userservice.response.ProductResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;

@Component
public class OrderUtil {

    @Autowired
    private ProductRestConsumer consumer;

    @Autowired
    private UserRepository userRepository;

    public Order orderRequestToOrder(OrderRequest orderRequest){
        Order order = new Order();
        order.setOrderId( orderRequest.getOrderId());
        order.setUser(userRepository.getById(orderRequest.getUserId()));
        //check if product is available and quantity is less the availability

        LinkedHashMap data = (LinkedHashMap) ((consumer.getProductById(orderRequest.getProductId()).getBody()));

        LinkedHashMap productMap = (LinkedHashMap) data.get("data");

        if(productMap.containsKey("productId")){
            if((int)productMap.get("productQuantity") >= orderRequest.getQuantity()){
                order.setProductId( orderRequest.getProductId());
                order.setQuantity(orderRequest.getQuantity());
            }
            else{
                throw new RuntimeException("Requested quantity is higher than existing quantity");
            }
        }else{
            throw new ResourceNotFoundException("Product does not exist");
        }

        return order;
    }

    public OrderResponse orderToOrderResponse(Order order){
        OrderResponse orderResponse = new OrderResponse();
        orderResponse.setOrderId( order.getOrderId());
        orderResponse.setUserId(order.getUser().getUserId());
        orderResponse.setProduct(this.productIdToProductResponse(order));
        orderResponse.setQuantity(order.getQuantity());
        return orderResponse;
    }

    public ProductResponse productIdToProductResponse(Order order){

        LinkedHashMap data = (LinkedHashMap) ((consumer.getProductById(order.getProductId()).getBody()));
        LinkedHashMap productMap = (LinkedHashMap) data.get("data");
        LinkedHashMap categoryMap = (LinkedHashMap) productMap.get("category");

        ProductResponse productResponse = new ProductResponse();
        productResponse.setProductId(order.getProductId());
        productResponse.setProductName((String) productMap.get("productName"));

        CategoryResponse categoryResponse = new CategoryResponse();
        categoryResponse.setCategoryId((int) categoryMap.get("categoryId"));
        categoryResponse.setCategory((String) categoryMap.get("category"));

        productResponse.setCategory(categoryResponse);
        return productResponse;
    }

    public Order updateOrder(OrderRequest orderRequest, Order order){
        order.setUser(userRepository.getById(orderRequest.getUserId()));
        LinkedHashMap data = (LinkedHashMap) ((consumer.getProductById(orderRequest.getProductId()).getBody()));

        LinkedHashMap productMap = (LinkedHashMap) data.get("data");
        if(productMap.containsKey("productId")){
            if((int)productMap.get("productQuantity") >= orderRequest.getQuantity()){
                order.setProductId( orderRequest.getProductId());
                order.setQuantity(orderRequest.getQuantity());
            }
            else{
                throw new RuntimeException("Requested quantity is higher than existing quantity");
            }
        }else{
            throw new ResourceNotFoundException("Product does not exist");
        }
        return order;
    }



}
